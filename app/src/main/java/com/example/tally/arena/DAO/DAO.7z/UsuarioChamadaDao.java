package com.example.tally.arena.DAO;

import com.example.tally.arena.jdbc.Factory;
import com.example.tally.arena.model.Chamada;
import com.example.tally.arena.model.Enum.UsuChaType;
import com.example.tally.arena.model.UsuarioChamada;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class UsuarioChamadaDao {

    public static LinkedList<UsuarioChamada> getUsuCha(Chamada ch) throws Exception{
        Factory fc =  new Factory();
        Connection connect = fc.getConnection();
        if(fc.e != null) throw fc.e;
        Statement statement = connect.createStatement();
        String consult = "SELECT * FROM `user_chamada` WHERE `idChamada`="+ch.getId();
        ResultSet resultSet = statement.executeQuery(consult);
        LinkedList<UsuarioChamada> result = new LinkedList<>();

        while(resultSet.next()) {
            int idTeen = resultSet.getInt(1);
            int idChamada = resultSet.getInt(2);
            int tipo = resultSet.getInt(3);
            int pontoExtra = resultSet.getInt(4);
            boolean presenca = resultSet.getBoolean(5);
            boolean pontualidade = resultSet.getBoolean(6);
            boolean anotDomingo = resultSet.getBoolean(7);
            boolean anotArena = resultSet.getBoolean(8);
            boolean meditacao = resultSet.getBoolean(9);
            int versiculo = resultSet.getInt(10);

            UsuarioChamada temp = new UsuarioChamada(idTeen, idChamada, null, null, UsuChaType.byInt(tipo), pontoExtra, presenca, pontualidade, anotDomingo, anotArena, meditacao, versiculo);

            result.add(temp);
        }
        fc.desconecta();
        return result;
    }

}
