package com.example.tally.arena.DAO;

import com.example.tally.arena.jdbc.Factory;
import com.example.tally.arena.model.Chamada;
import com.example.tally.arena.model.Enum.Sexo;
import com.example.tally.arena.model.Enum.UserType;
import com.example.tally.arena.model.GA;
import com.example.tally.arena.model.Teen;
import com.example.tally.arena.model.Usuario;
import com.example.tally.arena.model.UsuarioChamada;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class GADao {

	public static GA carregaGA(ResultSet rs) throws  SQLException{
		int id 			= rs.getInt(1);
		String nome		= rs.getString(3);
		int sexo		= rs.getInt(4);
		String codigo 	= rs.getString(5);
		GA result = new GA(id, nome, Sexo.byInt(sexo), null, new LinkedList<Teen>(), new LinkedList<Chamada>(), codigo);
		return result;
	}

	public static LinkedList<GA> getAll(int id) throws Exception{
		//para cada GA faca:
		// chama a fun��o carrega ga -> fun��o carrega ga tambem deve carrega os teens
		//fimpara

		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "SELECT * FROM `ga` WHERE `arena`="+id;
		
		Statement statement = connect.createStatement();
		ResultSet resultSet = statement.executeQuery(consult);
		
		LinkedList<GA> result = new LinkedList<>();
		
		while(resultSet.next()) {
			result.add(carregaGA(resultSet));
		}

		LinkedList<Usuario> teens = UsuarioDao.getAllType(UserType.Teen, id);

		for(Usuario us:teens){
			Teen tn = (Teen) us;
			for(GA ga:result){
				if(tn.getIdGA() == ga.getId()){
					tn.setGa(ga);
					ga.getTeens().add(tn);
				}
			}
		}

		for(GA ga:result){
			ga.getChamadas().addAll(ChamadaDao.getAll(ga));

			for(Chamada ch:ga.getChamadas()){
				LinkedList<UsuarioChamada> usCha = UsuarioChamadaDao.getUsuCha(ch);
				for(UsuarioChamada temp:usCha){
					for(Teen tn:ga.getTeens()){
						if(tn.getId() == temp.getIdTeen()){
							tn.getChamada().add(temp);
							ch.getTeens().add(temp);
							temp.setChamada(ch);
							temp.setTeen(tn);
						}
					}
				}

			}
		}
		fc.desconecta();
		return result;
	}
	
	public static boolean isUsed(String nome) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "SELECT * FROM `ga` WHERE ga_nome=\'"+nome+"\'";
		Statement statement = connect.createStatement();
		ResultSet resultSet = statement.executeQuery(consult);
		boolean result = resultSet.next();
		fc.desconecta();
		return result;
	}
	
	public static void Cadastrar(GA ga) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		
		String consult = "INSERT INTO `ga`(`ga_nome`) VALUES (?)";
		PreparedStatement pstmt = connect.prepareStatement(consult);

		pstmt.setInt(1, ga.getId());
		pstmt.setInt(2, ga.getArena().getId());
		pstmt.setString(3, ga.getNome());
		pstmt.setInt(4, ga.getSexo().ordinal());

		pstmt.executeUpdate();
		
		fc.desconecta();
		return;
	}

}
