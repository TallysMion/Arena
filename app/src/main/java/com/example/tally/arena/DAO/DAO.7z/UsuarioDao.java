package com.example.tally.arena.DAO;

import com.example.tally.arena.Exception.CodNotFound;
import com.example.tally.arena.Exception.GaNotFound;
import com.example.tally.arena.Exception.UserNotFound;
import com.example.tally.arena.jdbc.Factory;
import com.example.tally.arena.model.Arena;
import com.example.tally.arena.model.Enum.UserType;
import com.example.tally.arena.model.GA;
import com.example.tally.arena.model.Lider;
import com.example.tally.arena.model.Teen;
import com.example.tally.arena.model.Usuario;
import com.example.tally.arena.model.UsuarioChamada;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.LinkedList;



public class UsuarioDao {

	public static Usuario carregaUsuario(ResultSet rs) throws Exception{
		int id  			= rs.getInt(1);
		int tipcod 			= rs.getInt(2);
		int extId			= rs.getInt(3);
		int arenaId 		= rs.getInt(4);
		String nome			= rs.getString(5);
		String login		= rs.getString(6);
		String senha		= rs.getString(7);
		String email		= rs.getString(8);
		java.sql.Date nasc	= rs.getDate(9);
		String telefone		= rs.getString(10);

		Usuario result = null;
		UserType tipo = UserType.byInt(tipcod);
		switch (tipo){
			case Lider:
				result = new Lider(id, nome, login, senha, email, nasc, telefone, arenaId);
				break;
			case Teen:
				Factory fc =  new Factory();
				Connection connect = fc.getConnection();
				if(fc.e != null) throw fc.e;
				String consult = "SELECT * FROM `teen` WHERE `id`="+extId;
				Statement statement = connect.createStatement();
				ResultSet resultSet = statement.executeQuery(consult);

				int ga 		= resultSet.getInt(3);
				int pont	= resultSet.getInt(4);

				result = new Teen(id, nome, login, senha, email, nasc, telefone, arenaId, ga, new LinkedList<UsuarioChamada>(), pont);
				fc.desconecta();
				break;
		}

		return result;

	}

	//verificar
	public static Usuario login(String login, String senha) throws Exception{
		//verifica se as informa��es s�o validas
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "SELECT * FROM `usuario` WHERE `login`="+login+" AND `senha`="+senha;
		Statement statement = connect.createStatement();
		ResultSet resultSet = statement.executeQuery(consult);

		Usuario us = carregaUsuario(resultSet);
		fc.desconecta();
		if(us==null) throw new UserNotFound();

		//carrega o banco de dados
		Arena arena = ArenaDao.getArena(us.getIdArena());

		//retorna o usuario relacionado as informa��es
		if(us.getTipo().equals(UserType.Lider)){
			for(Lider ld:arena.getLideres()){
				if(ld.getId() == us.getId()){
					return ld;
				}
			}
		}

		if(us.getTipo().equals(UserType.Teen)){
			for(GA ga:arena.getGas()){
				if(ga.getId() == ((Teen) us).getIdGA()){
					for(Teen tn:ga.getTeens()){
						if(tn.getId() == us.getId()){
							return tn;
						}
					}
					break;
				}
			}
		}

		throw new UserNotFound();
	}

	//Recupera os Usuarios de 'tipo', s� carrega informa��es primarias
	public static LinkedList<Usuario> getAllType(UserType tipo, int extId) throws Exception{
		//recupera todos os usuarios do tipo
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "SELECT * FROM `usuario` WHERE `tipo`="+tipo.ordinal()+" AND `arena`="+extId;
		Statement statement = connect.createStatement();
		ResultSet resultSet = statement.executeQuery(consult);

		//cria uma lista vazia de usuarios
		LinkedList<Usuario> result = new LinkedList<>();


		while(resultSet.next()){
			result.add(carregaUsuario(resultSet));
		}
		fc.desconecta();
		//retorna a lista
		return result;

	}
	
	//verificar
	public static boolean isUsed(String login) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "SELECT * FROM `usuario` WHERE `login`="+login;
		Statement statement = connect.createStatement();
		ResultSet resultSet = statement.executeQuery(consult);
		boolean result = resultSet.next();
		fc.desconecta();
		return result;
	}
	
	
	//verificar
	public static boolean Cadastrar(String login, String senha, String nome, String telefone, java.sql.Date nasc, String email, String codigo) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		Statement statement = connect.createStatement();
		PreparedStatement pstmt;
		ResultSet resultSet;
		int extId = -1;
		String consult = "";
		UserType tipo = null;

		consult = "SELECT * FROM `ga` WHERE `codigo`="+codigo;
		resultSet = statement.executeQuery(consult);
		if(resultSet.next()){
			int gaId = resultSet.getInt(1);
			int arenaId = resultSet.getInt(2);
			tipo = UserType.Teen;

			consult = "INSERT INTO `teen`(`userId`, `ga`, `pontuacao`) VALUES (?,?,?)";
			pstmt = connect.prepareStatement(consult);
			pstmt.setInt(1, -1);
			pstmt.setInt(2, gaId);
			pstmt.setInt(3, 0);
			pstmt.execute();

			consult = "SELECT * FROM `teen` WHERE `userId`=-1";
			resultSet = statement.executeQuery(consult);
			int teenId = resultSet.getInt(1);

			consult = "INSERT INTO `usuario`(`tipo`, `extid`, `arena`, `nome`, `login`, `senha`, `email`, `dataNasc`, `telefone`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = connect.prepareStatement(consult);
			pstmt.setInt(1, tipo.ordinal());
			pstmt.setInt(2, teenId);
			pstmt.setInt(3, arenaId);
			pstmt.setString(4, nome);
			pstmt.setString(5, login);
			pstmt.setString(6, senha);
			pstmt.setString(7, email);
			pstmt.setDate(8, nasc);
			pstmt.setString(9, telefone);
			pstmt.executeUpdate();

			consult = "SELECT * FROM `usuario` WHERE `login`="+login;
			resultSet = statement.executeQuery(consult);
			int id = resultSet.getInt(1);

			consult = "UPDATE `teen` SET `userId`=? WHERE `id`=?";
			pstmt = connect.prepareStatement(consult);
			pstmt.setInt(1, id);
			pstmt.setInt(2, teenId);
			pstmt.executeUpdate();
			fc.desconecta();
			return true;
		}

		consult = "SELECT * FROM `arena` WHERE `codigo`="+codigo;
		resultSet = statement.executeQuery(consult);
		if(resultSet.next()){

			int arenaId = resultSet.getInt(1);

			consult = "INSERT INTO `usuario`(`tipo`, `extid`, `arena`, `nome`, `login`, `senha`, `email`, `dataNasc`, `telefone`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = connect.prepareStatement(consult);
			pstmt.setInt(1, tipo.ordinal());
			pstmt.setInt(2, -1);
			pstmt.setInt(3, arenaId);
			pstmt.setString(4, nome);
			pstmt.setString(5, login);
			pstmt.setString(6, senha);
			pstmt.setString(7, email);
			pstmt.setDate(8, nasc);
			pstmt.setString(9, telefone);
			pstmt.executeUpdate();
			fc.desconecta();
			return true;
		}

		fc.desconecta();
		throw new CodNotFound();
	}

	//verificar
	public static boolean updateData(Usuario user, String nlogin, String nNome, String nTel, java.sql.Date nNasc, String nEmail) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "UPDATE `usuario` SET `nome`=?,`login`=?, `email`=?,`dataNasc`=?,`telefone`=? WHERE `id`=?";
		PreparedStatement pstmt = connect.prepareStatement(consult);
		pstmt.setString(1, 	(nNome!=null 	&& !nNome.equals(""))	?nNome	:	user.getNome());
		pstmt.setString(2, 	(nlogin!=null 	&& !nlogin.equals(""))	?nlogin	:	user.getLogin());
		pstmt.setString(3, 	(nEmail!=null 	&& !nEmail.equals(""))	?nEmail	:	user.getEmail());
		pstmt.setDate(4, 		(nNasc!= null)							?nNasc	:	user.getDataNasc());
		pstmt.setString(5, 	(nTel!=null 	&& !nTel.equals(""))	?nTel	:	user.getTelefone());
		pstmt.executeUpdate();
		fc.desconecta();
		return true;
	}

	//verificar
	public static boolean updateKey(Usuario user, String nSenha) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "UPDATE `usuario` SET `senha`=? WHERE `id`=?";
		PreparedStatement pstmt = connect.prepareStatement(consult);
		pstmt.setString	(1, 	(nSenha!=null 	&& !nSenha.equals(""))	?nSenha	:	user.getSenha());
		pstmt.setInt	(2, 	user.getId());
		pstmt.executeUpdate();
		fc.desconecta();
		return true;
	}

	//verificar
	public static boolean changeGA(Teen teen, String codigo) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		Statement statement = connect.createStatement();
		String consult = "SELECT * FROM `ga` WHERE `codigo`="+codigo;
		ResultSet resultSet = statement.executeQuery(consult);
		if(!resultSet.next()) throw new GaNotFound();
		int nGa = resultSet.getInt(1);

		consult = "UPDATE `teen` SET `ga`=? WHERE `userId`=?";
		PreparedStatement pstmt = connect.prepareStatement(consult);
		pstmt.setInt(1, nGa);
		pstmt.setInt(2, teen.getId());
		pstmt.executeUpdate();
		fc.desconecta();

		for(GA ga:teen.getArena().getGas()){
			if(ga.getId() == nGa){
				teen.getGa().getTeens().remove(teen);
				teen.setGa(ga);
				ga.getTeens().add(teen);
			}
		}
		return true;
	}

	//verificar
	public static Usuario reloadDatabase(Usuario user) throws Exception{
		return login(user.getLogin(), user.getSenha());
	}



}
