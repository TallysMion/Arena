package com.example.tally.arena.DAO;

import com.example.tally.arena.jdbc.Factory;
import com.example.tally.arena.model.Chamada;
import com.example.tally.arena.model.Enum.Estado;
import com.example.tally.arena.model.GA;
import com.example.tally.arena.model.UsuarioChamada;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;


public class ChamadaDao {

	public static Chamada carregaChamada(ResultSet rs) throws  SQLException{
		int id = rs.getInt(1);
		int fechamento = rs.getInt(3);
		int estado = rs.getInt(4);
		java.sql.Date data = rs.getDate(5);
		Chamada result = new Chamada(id, Estado.byInt(estado), data, fechamento, null, new LinkedList<UsuarioChamada>());
		return result;
	}

	public static LinkedList<Chamada> getAll(GA ga) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "SELECT * FROM `chamada` WHERE `ga`="+ga.getId();

		Statement statement = connect.createStatement();
		ResultSet resultSet = statement.executeQuery(consult);

		LinkedList<Chamada> result = new LinkedList<>();

		while(resultSet.next()) {
			Chamada temp = carregaChamada(resultSet);
			temp.setGa(ga);
			result.add(temp);
		}

		return result;
	}

}
