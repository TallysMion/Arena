package com.example.tally.arena.DAO;

import com.example.tally.arena.jdbc.Factory;
import com.example.tally.arena.model.Constantes;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

class ConstantesDao {
    public static Constantes getConstante(int idArena) throws Exception{
        Factory fc =  new Factory();
        Connection connect = fc.getConnection();
        if(fc.e != null) throw fc.e;
        String consult = "SELECT * FROM `Constantes` WHERE `arena`="+idArena;
        Statement statement = connect.createStatement();
        ResultSet resultSet = statement.executeQuery(consult);

        Constantes result = null;

        if(resultSet.next()){
            int id = resultSet.getInt(1);
            int presArena = resultSet.getInt(3);
            int presImers = resultSet.getInt(4);
            int pontualidade = resultSet.getInt(5);
            int anotArena = resultSet.getInt(6);
            int anotImers = resultSet.getInt(7);
            int meditacao = resultSet.getInt(8);
            int versiculo = resultSet.getInt(9);

            result = new Constantes(id, presArena, presImers, pontualidade, anotArena, anotImers, meditacao, versiculo);

        }
        return  result;
    }

    public static  boolean insertConstante(Constantes cn, int idArena) throws Exception{
        Factory fc =  new Factory();
        Connection connect = fc.getConnection();
        if(fc.e != null) throw fc.e;
        String consult = "INSERT INTO `constantes`(`arena`, `presencaArena`, `presencaImersao`, `pontualidade`, `anotArena`, `anotDomingo`, `meditacao`, `versiculo`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pstmt = connect.prepareStatement(consult);
        pstmt.setInt(1, idArena);
        pstmt.setInt(2, cn.presencaArena);
        pstmt.setInt(3, cn.presencaImersao);
        pstmt.setInt(4, cn.pontualidade);
        pstmt.setInt(5, cn.anotArena);
        pstmt.setInt(6, cn.anotDomin);
        pstmt.setInt(7, cn.meditacao);
        pstmt.setInt(8, cn.versiculo);
        pstmt.executeUpdate();
        fc.desconecta();
        return true;
    }
}
