package com.example.tally.arena.DAO;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

import com.example.tally.arena.Exception.CadArena;
import com.example.tally.arena.Exception.CodNotFound;
import com.example.tally.arena.Utils.Codigo;
import com.example.tally.arena.jdbc.Factory;
import com.example.tally.arena.model.*;
import com.example.tally.arena.model.Enum.*;

public class ArenaDao {

	
	 public Arena loadDatabase(int id) throws Exception{
	     //chama a fun��o carrega arena
		 Arena arena = getArena(id);

	     //Carregar os lideres do arena
		 LinkedList<Usuario> liders = UsuarioDao.getAllType(UserType.Lider, id);

		 //informa para lider o arena e inclui o lider na arena
		 for(Usuario us:liders) {
			 ((Lider) us).setArena(arena);
			 arena.getLideres().add((Lider) us);
		 }
			
		 //Carregar os Gas do arena, o arena já possui os Teens e as chamadas e relaciona chamada/teen
		 arena.getGas().addAll(GADao.getAll(id));
		 //informa para Ga o arena
		 for(GA ga:arena.getGas())
		 	ga.setArena(arena);

			
		 //Carregar os Fechamentos do Arena
		 arena.setFechamentos(FechamentoDao.getFechamentos(arena));
		 //Relaciona fechamento com chamada
		 for(GA ga:arena.getGas()){
		 	for(Chamada ch:ga.getChamadas()){
		 		if(ch.getEstado().equals(Estado.close)){
		 			for(Fechamento fc:arena.getFechamentos()){
		 				if(ch.getFechamentoId() == fc.getId()){
		 					ch.setFechamento(fc);
		 					fc.getChamadas().add(ch);
						}
					}
				}
			}
		 }

		 //retorna o Arena
		 return arena;
	}
	
	public static Arena getArena(int id) throws Exception {
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "SELECT * FROM `arena` WHERE `id`="+id;
		Statement statement = connect.createStatement();
		ResultSet resultSet = statement.executeQuery(consult);
		Arena result = null;
		if(resultSet.next()){
			id 				= resultSet.getInt(1);
			String nome 	= resultSet.getString(2);
			String endereco = resultSet.getString(3);
			String igrejaMae= resultSet.getString(4);
			int diaSemana	= resultSet.getInt(5);
			int hr[] = new int[2];
			hr[0]			= resultSet.getInt(6);
			hr[1]			= resultSet.getInt(7);
			String codigo	= resultSet.getString(8);

			Constantes cons = ConstantesDao.getConstante(id);

			result = new Arena(id, nome, endereco, igrejaMae, Semana.byInt(diaSemana), hr, new LinkedList<Lider>(), new LinkedList<GA>(), new LinkedList<Fechamento>(), cons, codigo);
		}
		fc.desconecta();
		return result;
	}

	public static boolean criarCodigo(String nome, String igreja) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
	 	Codigo cd = new Codigo(nome, igreja);
		String consult = "INSERT INTO `codigo`(`nome`, `igreja`, `codigo`) VALUES (?, ?, ?)";
		PreparedStatement pstmt = connect.prepareStatement(consult);
		pstmt.setString(1, cd.getNome());
		pstmt.setString(2, cd.getIgreja());
		pstmt.setString(3, cd.getCodigo());
		pstmt.executeUpdate();
		fc.desconecta();
		return true;
	}

	public static Codigo getCodigo(String nome, String codigo) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		Statement statement = connect.createStatement();
		String consult = "SELECT * FROM `codigo` WHERE `nome`="+nome+" AND `codigo`="+codigo;
		ResultSet resultSet = statement.executeQuery(consult);
		if(resultSet.next()){
			return new Codigo(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4));
		}
		throw new CodNotFound();
	}

	public static boolean CadastrarArena(Codigo cd, String nome, String endereco, String igrejaMae, Semana diaSem, int hr, int min, Constantes cn) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "INSERT INTO `arena`(`nome`, `endereco`, `igrejaMae`, `diaDaSemana`, `horarioHr`, `horarioMin`, `codigo`) VALUES (?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement pstmt = connect.prepareStatement(consult);
		pstmt.setString(1, nome);
		pstmt.setString(2, endereco);
		pstmt.setString(3, igrejaMae);
		pstmt.setInt(4, diaSem.ordinal());
		pstmt.setInt(5, hr);
		pstmt.setInt(6, min);
		pstmt.setString(7, cd.getCodigo());
		pstmt.executeUpdate();

		Statement statement = connect.createStatement();
		consult = "SELECT * FROM `arena` WHERE `nome`="+nome+" AND `codigo`="+cd.getCodigo();
		ResultSet resultSet = statement.executeQuery(consult);
		if(!resultSet.next()){
			throw new CadArena();
		}
		int idArena = resultSet.getInt(1);

		ConstantesDao.insertConstante(cn, idArena);

		consult = "DELETE FROM `codigo` WHERE `id`="+cd.getId();
		statement.executeQuery(consult);
		fc.desconecta();
		return true;
	 }
	
	
}
