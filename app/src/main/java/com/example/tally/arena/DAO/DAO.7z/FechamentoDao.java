package com.example.tally.arena.DAO;

import com.example.tally.arena.jdbc.Factory;
import com.example.tally.arena.model.Arena;
import com.example.tally.arena.model.Chamada;
import com.example.tally.arena.model.Fechamento;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;

public class FechamentoDao {

	public static Fechamento carregaFechamento(ResultSet rs) throws SQLException{

		int id 				= rs.getInt(1);
		java.sql.Date inic  = rs.getDate(3);
		java.sql.Date end	= rs.getDate(4);

		return new Fechamento(id, inic, end, null, new LinkedList<Chamada>());
	}

	public static LinkedList<Fechamento> getFechamentos(Arena arena) throws Exception{
		Factory fc =  new Factory();
		Connection connect = fc.getConnection();
		if(fc.e != null) throw fc.e;
		String consult = "SELECT * FROM `fechamento` WHERE `arena`="+arena.getId();
		Statement statement = connect.createStatement();
		ResultSet resultSet = statement.executeQuery(consult);

		LinkedList<Fechamento> result = new LinkedList<>();
		while(resultSet.next()){
			Fechamento temp = carregaFechamento(resultSet);
			temp.setArena(arena);
			result.add(temp);
		}
		fc.desconecta();
		return result;
	}



}
